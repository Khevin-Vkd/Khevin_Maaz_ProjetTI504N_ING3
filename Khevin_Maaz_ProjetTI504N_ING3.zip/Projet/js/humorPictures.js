export const humorPictures = {
    baddie : [
        "../img/moods/slay_gurl.jpg",
        "../img/moods/outfits/baddie_outfit_1.jpg",
        "../img/moods/outfits/baddie_outfit_2.jpg",
        "../img/moods/outfits/baddie_outfit_3.jpg",
        "../img/moods/makeup/baddie_makeup.jpeg",
        "../img/moods/hairstyle/baddie_hairstyle.jpeg",
    ],
    princess : [
        "../img/moods/princess.jpeg",
        "../img/moods/outfits/princess_outfit_1.jpg",
        "../img/moods/outfits/princess_outfit_2.jpg",
        "../img/moods/outfits/princess_outfit_3.jpg",
        "../img/moods/makeup/princess_makeup.jpeg",
        "../img/moods/hairstyle/princess_hairstyle.jpg",
    ],
    "clean girl" : [
        "../img/moods/clean_girl.jpg",
        "../img/moods/outfits/clean_outfit_1.jpeg",
        "../img/moods/outfits/clean_outfit_2.jpeg",
        "../img/moods/outfits/clean_outfit_3.jpeg",
        "../img/moods/makeup/clean_girl_makeup.jpeg",
        "../img/moods/hairstyle/clean_girl_hairstyle.jpg",
    ],
    casual : [
        "../img/moods/casual.jpg",
        "../img/moods/outfits/casual_outfit_1.jpg",
        "../img/moods/outfits/casual_outfit_2.jpg",
        "../img/moods/outfits/casual_outfit_3.jpg",
        "../img/moods/makeup/casual_makeup.jpeg",
        "../img/moods/hairstyle/casual_hairstyle.jpg",
    ],
    cutie : [
        "../img/moods/cute.webp",
        "../img/moods/outfits/cutie_outfit_1.jpg",
        "../img/moods/outfits/cutie_outfit_2.jpg",
        "../img/moods/outfits/cutie_outfit_3.jpg",
        "../img/moods/makeup/cutie_makeup.jpeg",
        "../img/moods/hairstyle/cute_hairstyle.webp",
    ],
    work : [
        "../img/moods/work.jpg",
        "../img/moods/outfits/work_outfit_1.jpg",
        "../img/moods/outfits/work_outfit_2.jpg",
        "../img/moods/outfits/work_outfit_3.jpg",
        "../img/moods/makeup/office_makeup.jpeg",
        "../img/moods/hairstyle/work_hairstyle.webp",
    ],

}

export const humeurs = Object.keys(humorPictures);

// Mots synonymes : chaque mot de la liste renvoie les mêmes images
const synonymes = {
    baddie: ["bad bitch", "boss", "bad girl", "slay"],
    princess: ["girly", "royal", "queen", "diva"],
    "clean girl": ["minimal", "simple", "fresh", "clean"],
    casual: ["relax", "chill", "comfy"],
    cutie: ["cute", "sweet", "kawaii"],
    work: ["bureau", "office", "business"],
};

for (const [humeur, alias] of Object.entries(synonymes)) {
    alias.forEach((mot) => {
        humorPictures[mot] = humorPictures[humeur];
    });
}

