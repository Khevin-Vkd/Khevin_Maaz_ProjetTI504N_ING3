alert("Welcome back gorgeous, looking for improving your looks ?");

import { humorPictures, humeurs } from "./humorPictures.js";

document.addEventListener('DOMContentLoaded', () => {
      const buttonHumor = document.getElementById('boutonHumor');
      const humor = document.getElementById('humor');

     function updateHumor(humor){
         humor = humor.trim().toLowerCase();
          const pictures = humorPictures[humor];

          if (pictures){
              const img = document.querySelectorAll(".humorPictures");
              img.forEach((image, index) => {
                  if (pictures[index]) {
                      image.src = pictures[index];
                  }
              });
          }else{
              alert("Gurl, you selected the wrong mood, you can either put : " + Object.keys(humorPictures).join(", ") + ".");
          }
     }

      buttonHumor.addEventListener('click', () => {
          updateHumor(humor.value);
      });
      
});